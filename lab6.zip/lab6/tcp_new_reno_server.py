import socket
import os
import threading
import time

HOST="localhost"
PORT=8000
ENCODER="utf-8"
stack=[]
ack=0
stop_thread=False
rwnd=900
duplicate_ack=0

def packet_making(src_port,dest_port,seq_num,ack,payload,recv_window):
    header=f"{src_port:06d}{dest_port:06d}{seq_num:06d}{ack:06d}{recv_window:06d}"
    header=header.encode(ENCODER)
    packet=header+payload
    return packet

# extracts ack & rcvwnd from a pkt
def extract(message):
    ack=message[0:6]
    rwnd=message[6:12]
    return(int(ack),int(rwnd))

def send(client,addr):
    global stack
    global ack
    global rwnd
    global duplicate_ack

    seq_num=0
    recv_window=200
    src_port=PORT
    dest_port=addr[1]
    acki=0
    mss=1
    ssthresh=8 #Threshold selected to 8 initially
    threshold_flag=0
    file=open("sent_file.txt","rb")
    file_size=os.path.getsize("sent_file.txt")
    print("File: ",file_size, " bytes")
    rec=0
    #Timeout is 2 second
    timeout=2
    Transmission_Round=1

    # base seq num = 0 & num of segmnts(size) to be sent
    base=0
    size=(int)(file_size/recv_window)
    cwnd=min(mss,size)*recv_window
    packet_loss=0

    #Creating receiving thread
    newthread=threading.Thread(target=recieve,args=(client,))
    newthread.start()
    st=time.time()
    last_seq=0
    while True:
        # checks if entire file has been transmitted, if so breaks the loop
        if base>=file_size:
            break

        # allows to resume reading from the next position
        file.seek(rec)
        while seq_num<cwnd:
            payload=file.read(recv_window)
            # if no more data, break it
            if not payload:
                break
            print("Total bytes sent: ",seq_num)
            packet=packet_making(src_port,dest_port,seq_num,acki,payload,recv_window)
            client.send(packet)
            seq_num+=recv_window
            time.sleep(0.01)
        start=time.time()

        #Is it Timeout
        while time.time()-start<= timeout:
            # if last pkt=curr seq num, successful trnsmsn, break the loop
            if stack[-1]==seq_num:
                break

            # ___________TCP New Reno_____________
            # 3 duplicate ack, ssthresh halved & mss=ssthresh, fast recovery
            elif duplicate_ack>=3:
                # if latest rcvd ack < last seqnum, means ack is 
                # rcvd for the same cwnd. don't half ssthresh
                if stack[-1]<last_seq:
                    threshold_flag=1   # don't half ssthresh
                    duplicate_ack=0
                    break
                else:
                    ssthresh=mss//2   # half ssthresh
                    mss=ssthresh
                    threshold_flag=1    
                    duplicate_ack=0
                    break

         # timeout, ssthresh halved & mss=1
        if time.time()-start > timeout:
            print("\n!Time out!!!")
            ssthresh=mss//2
            mss=1
            threshold_flag=0

        # 3 duplicate acks, fast retransmit
        elif threshold_flag==1:
            mss+=1
            print("3 duplicate retransmit required")
        
        # congestion avoidance
        elif threshold_flag==0 and mss >= ssthresh:
            print("__Threshold value excedded so congesiton avoidance happening\n")
            mss+=1

        # slow start
        else:
            mss=mss*2
    
        print("ACK",stack[-1])

        #Getting acknowledgement number and window size for flow control
        rec=stack[-1]
        recv_window=rwnd
        if rec> last_seq:
            last_seq=rec+mss*recv_window
        print("WINDOW", recv_window)
        cwnd=rec+mss*recv_window
        packet_loss+=seq_num-rec
        print(f"Cwnd size = {cwnd} mss = {mss} Time =  {time.time()-st} packet loss = {packet_loss}")
        Transmission_Round+=1
        print("\nTransmission Round",Transmission_Round)
        base=rec
        seq_num=base
        stack.clear()
        
    client.send(b"<END>")

    file.close()

    print(f"Disconnected with {addr[0]} : {addr[1]}")
    ed=time.time()
    Throughput=file_size/(ed-st)
    print("Throughput: ",Throughput,"B/s")
    stop_thread=True
    

def recieve(client):
    global stack
    global ack
    global rwnd
    global duplicate_ack

    last=0

    try:
        while True:
            if stop_thread==True:
                break
            message=client.recv(1024).decode(ENCODER)
            ack,rwnd=extract(message)
            # if ack = prev ack, increment dup ack
            if ack==last:
                duplicate_ack+=1
            else:
                duplicate_ack=0
            last=ack
            stack.append(ack)
    except:
        print("RECEIVED connection has been CLOSED!!!")


def main():

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))

    server_socket.listen()

    print("SERVER IS LISTENING......")

    try:
        client, addr = server_socket.accept()
        print(f"Connected with {addr[0]} : {addr[1]}")
        send(client,addr)
        
    except KeyboardInterrupt:
        print("Stopped by Ctrl+C")
        
    
    server_socket.close()
    print("Connection closed")

if __name__=="__main__":
    main()