import socket
import os
import random

HOST="localhost"
PORT=8000
ENCODER="utf-8"


#  extract sequence number and receive window 
def extract(packet):
    packet=packet.decode(ENCODER)
    seq_num=packet[12:18]
    recv_window=packet[24:30]
    return (int(seq_num),int(recv_window))

def packet_making(ack,rwnd):
    header=f"{ack:06d}{rwnd:06d}"
    header=header.encode(ENCODER)
    return header

def main():
    client_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    client_socket.connect((HOST,PORT))
    print("Established Connection with sever...")

    file = open("recieve_file.txt","wb")
    seq_num=0
    rwnd=200
    f=0
    while True: 
        try:
            packet=client_socket.recv(1024)
        except:
            print("File reception failed...")
            break
        

        if packet.decode(ENCODER)=="<END>":
            break
        else:
            recv_seq_num,recv_win_num=extract(packet)
            payload=packet[30:]

        rd=random.randint(1,10)

        # simulating out of order packets
        if f>=16 and rd<2:
            print("Received out of order packet!!!!")
            ack=seq_num
            f=2
            # send ack to server
            header=packet_making(ack,rwnd)
            client_socket.send(header)
        
        # checks if the packets received in order
        elif recv_seq_num==seq_num :
            print(f"seq = {recv_seq_num}, rcvd wndw = {recv_win_num}, pload ={len(payload)}")
            #print(payload)
            file.write(payload)
            seq_num=seq_num+len(payload)
            rd=random.randint(1,5)

            # randomly generating values to simulate changes in rcvd wnd
            if rd==1:
                rwnd=500
            elif rd==2:
                rwnd=100
            elif rd==3:
                rwnd=300
            else:
                rwnd=200
            ack=seq_num
            f+=1
            # send ack to server
            header=packet_making(ack,rwnd)
            client_socket.send(header)
        else:
            print("Received out of order packet!!!!")
            ack=seq_num
            header=packet_making(ack,rwnd)
            client_socket.send(header)

    file.close()
    client_socket.close()
    print("\nSucessfully sent out of order packet")
            

    


if __name__=="__main__":
    main()